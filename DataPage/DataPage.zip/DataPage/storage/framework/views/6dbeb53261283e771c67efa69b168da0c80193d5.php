

<?php $__env->startSection('content'); ?>
<h1>Article</h1>

<table>
    <tr>
        <th>Date</th>
        <th>Title</th>
        <th>Created By</th>
        <th>content</th>
    </tr>
    <tr>
        <td><?php echo e($post->created_at); ?></td>
        <td><?php echo e($post->title); ?></td>
        <td><?php echo e($post->user->name); ?></td>
        <td><?php echo e($post->content); ?></td>
    </tr>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program\User\Documents\GitHub\DataPage\resources\views//posts/page.blade.php ENDPATH**/ ?>