

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container">
            <h3>Categories</h3>
            <hr>
        </div>

        <div class="container">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="/posts/category/<?php echo e($category->id); ?>">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($category->name); ?></h5>
                            <p class="card-text"> <?php echo e($post_counts[$key]); ?></p>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h5>There is no category!</h5>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program\User\Documents\GitHub\DataPage\resources\views/categories/all.blade.php ENDPATH**/ ?>