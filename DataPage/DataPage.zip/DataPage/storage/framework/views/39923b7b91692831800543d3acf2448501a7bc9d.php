

<?php $__env->startSection('content'); ?>

<div
    class="container-fluid bg-primary"
    style="s
        min-height: 300px;
        background-image: url('<?php echo e(asset('storage/banner_img.svg')); ?>');
        background-repeat: no-repeat;
        background-position: center;
    "
>
    <div class="container h-100 py-5">
        <div class="row justify-content-center">
            <div class="col-7">
                <h1 class="text-center text-white">Welcome to Data Santa. To satisfy all your research needs.</h1>
            </div>
        </div>
        <div class="row justify-content-center pt-3">
            <a class="btn btn-info btn-lg" href="#" role="button">View our articles</a>
        </div>
    </div>
</div>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(isset(Auth::user()->id) && (Auth::user()->role == 0)): ?>
                        <p> <a href="<?php echo e(url('home/my_article')); ?>">My Articles</a></p>
                    <?php endif; ?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program\User\Documents\GitHub\DataPage\resources\views/home.blade.php ENDPATH**/ ?>