

<?php $__env->startSection('content'); ?>

<h3 class="text-primary">Delete Article</h3>

<table>
    <tr>
        <th>Date</th>
        <th>Title</th>
        <th>Created By</th>
        <th>Operation</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($post->created_at); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->user->name); ?></td>
            <td>
                <form action="/admin/deleteArticle/<?php echo e($post->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                   
    
                    <button>delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="4">There is no post in this category!</td>
        </tr>
    <?php endif; ?>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program\User\Documents\GitHub\DataPage\resources\views/posts/admin-delete-page.blade.php ENDPATH**/ ?>