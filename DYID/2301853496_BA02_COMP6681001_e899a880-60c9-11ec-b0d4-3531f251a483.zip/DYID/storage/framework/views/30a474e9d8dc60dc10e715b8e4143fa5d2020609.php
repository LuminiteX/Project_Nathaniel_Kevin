

<?php $__env->startSection('content'); ?>
    <p class="title">New Products</p>

    <div class="gallery">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="gallery-item">
                <div class="gallery-item-top">
                    <img src="<?php echo e(url('storage/images/products/'. $product->image_path)); ?>" alt="">
                </div>
                <div class="gallery-item-bot">
                    <div class="gallery-item-bot-title">
                        <p class="gallery-item-bot-title-product"><?php echo e($product->name); ?></p>
                        <p class="gallery-item-bot-title-category"><?php echo e($product->category->name); ?></p>
                    </div>
                    <p class="gallery-item-bot-price"> IDR <?php echo e(number_format($product->price, 0, ',')); ?> </p>
                    <a class="gallery-item-bot-more" href="/product/<?php echo e($product->id); ?>">More Detail</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2>There is no product available</h2>
        <?php endif; ?>
    </div>

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <div class="pag">
        <?php echo e($data->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/home.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BINUS\DYID\resources\views/index.blade.php ENDPATH**/ ?>