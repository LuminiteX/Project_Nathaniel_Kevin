

<?php $__env->startSection('content'); ?>
<div class="insert">
    <div class="insert-form">
        <p>Insert New Category</p>
        <form action="">
            <input type="text" name="" id="" placeholder="Category name">
    
            <input type="submit" value="add">
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/insert_category.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DYID\resources\views/insert_category.blade.php ENDPATH**/ ?>