

<?php $__env->startSection('content'); ?>
<div class="login">
    <div class="login-form">
        <p>Welcome Back</p>
        <form action="">
            <input type="text" name="" id="" placeholder="Email">
            <input type="password" name="" id="" placeholder="Password">

            <div class="login-form-remember">
                <input type="checkbox" name="login_remember" id="login_remember">
                <label for="login_remember">Remember me</label>
            </div>
            
            <input type="submit" value="Login">
        </form>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DYID\resources\views/login.blade.php ENDPATH**/ ?>