

<?php $__env->startSection('content'); ?>
<div class="edit">
    <div class="edit-form">
        <p>Edit Category</p>
        <form action="">
            <select name="Category" id="Category" class="Category" style="width:700px; height: 40px;">
                <option value="Phone">Phone</option>
                <option value="Television">Television</option>
            </select>
    
            <input type="submit" value="add">
            
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/E_category.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DYID\resources\views/E_category.blade.php ENDPATH**/ ?>