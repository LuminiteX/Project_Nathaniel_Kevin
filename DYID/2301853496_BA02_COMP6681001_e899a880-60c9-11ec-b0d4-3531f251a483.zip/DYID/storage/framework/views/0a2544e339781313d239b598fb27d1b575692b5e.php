<div class="footer">
    <div class="footer-top">
        <a href=""><img src="<?php echo e(url('storage/images/icons/facebook_logo.png')); ?>" alt=""></a>
        <a href=""><img src="<?php echo e(url('storage/images/icons/instagram_logo.png')); ?>" alt=""></a>
        <a href=""><img src="<?php echo e(url('storage/images/icons/question_logo.png')); ?>" alt=""></a>
    </div>
    <div class="footer-bot">
        <p>© 2021 Copyright DY20-1</p>
    </div>
</div>
<link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>"><?php /**PATH C:\Users\kevin\Documents\GitHub\DYID\resources\views/layouts/footer.blade.php ENDPATH**/ ?>