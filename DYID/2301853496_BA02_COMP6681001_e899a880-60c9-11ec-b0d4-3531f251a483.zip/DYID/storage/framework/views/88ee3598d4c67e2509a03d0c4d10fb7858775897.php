

<?php $__env->startSection('content'); ?>
    <h1>Manage Product</h1>
    <table style="width:98%">
        <col style="width:3%">
	    <col style="width:14%">
        <col style="width:9%">
        <col style="width:27%">
        <col style="width:7%">
        <col style="width:10%">
	    <col style="width:20%">
        <tr>
            <th style="width:3%">No</td>
            <th style="width:14%">product Image</td>
            <th style="width:9%">Prdouct Name</td>
            <th style="width:20%">Product Description</td>
            <th style="width:7%">Product Price</td>
            <th style="width:10%">Product Category</td>
            <th style="width:10%">Action</td>
        </tr>
        <tr>
        <?php $__empty_1 = true; $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td style="width:3%"><?php echo e($product->id); ?></td>
            <td style="width:14%"><img src="<?php echo e(url('storage/images/products/'. $product->image_path)); ?>" alt="" width="150" height="100"></td>
            <td style="width:9%"><?php echo e($product->name); ?></td>
            <td style="width:20%"><?php echo e($product->description); ?></td>
            <td style="width:7%"><?php echo e($product->price); ?></td>
            <td style="width:10%"><?php echo e($product->category->name); ?></td>
            <td style="width:15%">
                <div class="ButtonI">
                    <a href="/product/edit/<?php echo e($product->id); ?>" class="Update">Update</a>
                    <form action="/product/delete/<?php echo e($product->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("delete"); ?>
                        <button type = "submit" class="Delete">Delete</button>
                    </form>
                </div>
                
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <td>No data</td>
            <td>No data</td>
            <td>No data</td>
            <td>No data</td>
            <td>No data</td>
            <td>No data</td>
            <td>No data</td>
        <?php endif; ?>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/view_product_list.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Sems 5\Kerkel\Final DYID\DYID\DYID\resources\views/products/manage_product.blade.php ENDPATH**/ ?>