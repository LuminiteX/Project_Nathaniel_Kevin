

<?php $__env->startSection('content'); ?>
    <h1>Manage Category</h1>
    <table style="width:96%">
        <col style="width:2%">
	    <col style="width:70%">
	    <col style="width:20%">
        <tr>
            <th>No</th>
            <th>Category Name</th>
            <th>Action</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($category->id); ?></td>
                <td><?php echo e($category->name); ?></td>
                <td class="btn">
                    <a href="/category/edit/<?php echo e($category->id); ?>" class="updateBtn">Update</a> 

                    <form action="/category/delete/<?php echo e($category->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("delete"); ?>
                        <button type = "submit" class="deleteBtn">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>No data</td>
                <td>No data</td>
                <td>No data</td>
            </tr>
        <?php endif; ?>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/manage_category.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DYID\resources\views/categories/manage_category.blade.php ENDPATH**/ ?>