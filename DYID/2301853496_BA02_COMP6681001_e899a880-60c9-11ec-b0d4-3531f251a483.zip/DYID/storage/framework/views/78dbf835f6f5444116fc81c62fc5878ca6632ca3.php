

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="edit_cart">
        <div class="edit_cart-left">
            <img src="<?php echo e(url('storage/images/products/'. $cart_item->image_path)); ?>" alt=""></th>
        </div>
        <div class="edit_cart-right">
            <h1 class="edit_cart-right-title"><?php echo e($cart_item->name); ?></h1>
            <hr>
            <h1 class="edit_cart-right-subtitle">Price:</h1>
            <p>IDR <?php echo e(number_format($cart_item->price)); ?></p>
            <hr>
            <h1 class="edit_cart-right-subtitle">Description:</h1>
            <p><?php echo e($cart_item->description); ?></p>
            <hr>
    
            <form action="/cart/edit/<?php echo e($cart_item->id); ?>" class="edit_cart-right-form" method='POST'>
                <?php echo csrf_field(); ?>
    
                <label for="item_quantity">Qty:</label>
                <input type="number" name='quantity' id='quantity' value=<?php echo e($cart_item->pivot->quantity); ?>>
                <input type="submit" value="Save">
    
                <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert" style="color: red" role='alert'><strong><?php echo e($message); ?></strong></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/edit_cart.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BINUS\DYID\resources\views/carts/edit_cart.blade.php ENDPATH**/ ?>