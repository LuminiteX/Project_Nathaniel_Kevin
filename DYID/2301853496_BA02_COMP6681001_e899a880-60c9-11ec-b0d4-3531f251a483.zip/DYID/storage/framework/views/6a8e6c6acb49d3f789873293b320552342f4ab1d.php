

<?php $__env->startSection('content'); ?>
    <div class="TableForContent">
        <div class="image">
            <img src="<?php echo e(asset('/images/logo.png')); ?>" alt=""></th>
        </div>
        <div class="textDescript">
            <h1>Samsung s21</h1>
            <hr>
            <h1>Category</h1>
            <br>
            smartphone
            <hr>
            <h1>Price</h1>
            <br>
            ID 14.999.000
            <hr>
            <h1>Description:</h1>
            <br>
            Witness blablabla
            <hr>
            <br>

            <button class="Login">Login to buy</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/DetailProductPage.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DYID\resources\views/DetailProductPage.blade.php ENDPATH**/ ?>