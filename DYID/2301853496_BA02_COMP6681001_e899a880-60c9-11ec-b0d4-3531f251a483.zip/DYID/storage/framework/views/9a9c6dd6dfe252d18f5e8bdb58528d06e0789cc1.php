<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <title>DYID</title>
    <style>
        /* Making sure of fullsize */
        html,body{
            width: 100%;
            height: 100%;
            margin: 0px;
            padding: 0px;
            min-height: 100vh;
            overflow-x:hidden;
        }

        body{
            background-color: rgb(235, 235, 235);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        footer,header, .content{
            padding: 0px;
            margin: 0px;
        }
        .content{
            min-height: calc(100vh - 137px - 114px);
        }
    </style>

    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    

<header>
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>


<div class="content">
    <?php echo $__env->yieldContent('content'); ?> 
</div>


<footer>
    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
</body>
</html><?php /**PATH D:\Binus\Sems 5\Kerkel\Final DYID\DYID\DYID\resources\views/layouts/app.blade.php ENDPATH**/ ?>