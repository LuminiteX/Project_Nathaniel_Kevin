

<?php $__env->startSection('content'); ?>
    <div class="product">
        <div class="product-left">
            <img src="<?php echo e(url('storage/images/products/'. $product->image_path)); ?>" alt=""></th>
        </div>
        <div class="product-right">
            <h1 class="product-right-title"><?php echo e($data->name); ?></h1>
            <hr>
            <h1 class="product-right-subtitle">Category:</h1>
            <p><?php echo e($data->category->name); ?></p>
            <hr>
            <h1 class="product-right-subtitle">Price:</h1>
            <p>IDR <?php echo e(number_format($data->price, 0, ',' , ' ')); ?></p>
            <hr>
            <h1 class="product-right-subtitle">Description:</h1>
            <p><?php echo e($data->description); ?></p>
            <hr>
    
            <?php if(auth()->guard()->guest()): ?>
                <a href="/login" class="login">Login to buy</a>
            <?php elseif(isset(Auth::user()->id) && (Auth::user()->role == 0)): ?>
                <form action="/cart/add/<?php echo e($data->id); ?>" class="product-right-form" method="POST">
                    <?php echo csrf_field(); ?>

                    <label for="quantity">Qty:</label>
                    <input type="number" name="quantity">
                    <input type="submit" value="Add To Cart">

                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert" style="color: red" role='alert'><strong><?php echo e($message); ?></strong></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/detail_product_page.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Sems 5\Kerkel\Latest DYID\DYID\DYID\resources\views/products/detail_product.blade.php ENDPATH**/ ?>