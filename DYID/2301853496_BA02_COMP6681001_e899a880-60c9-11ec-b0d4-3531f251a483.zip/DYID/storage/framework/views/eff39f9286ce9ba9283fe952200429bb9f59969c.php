


<?php $__env->startSection('content'); ?>

<div class= "transaction-header">
    <h2>My History Transaction</h2>
</div>


<?php $__empty_1 = true; $__currentLoopData = $user_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction_header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="panel-group" id="accordion">
        <div class="panel panel-default">
            <div class="panel-heading">
                <button class="panel-heading-accordion"><?php echo e($transaction_header->created_at); ?></button>
                <div class="panel-heading-accordion-description">
                    <?php $__currentLoopData = $transaction_header->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="table">
                        <div class="image">
                            <img src= "<?php echo e(url('storage/images/products/'. $product->image_path)); ?>" alt="" width="150" height="100">
                        </div>
                        <div class="desc">
                            <?php echo e($product->name); ?>  
                            <sup>
                                (IDR <?php echo e(number_format($product->price)); ?>)  
                            </sup>
                            <div class="peace">
                                x<?php echo e($product->pivot->quantity); ?> pcs
                            </div>
                        </div>
                        <div class="price">
                            <span>
                                IDR <?php echo e(number_format($product->pivot->quantity * $product->price)); ?>

                            </span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="totalprice">
                        <sub>
                            <b>Total Price: IDR <?php echo e(number_format($transaction_header->total_price)); ?></b>
                        </sub>    
                    </div>
                </div>
            </div>
        </div>
    </div>    
         
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h1> No data</h1>
<?php endif; ?>

<script type="text/javascript" src="<?php echo e(URL::asset('js/slider.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/history.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BINUS\DYID\resources\views/history.blade.php ENDPATH**/ ?>